DOMINIC PHOTO ENGINE — VISUAL CANON + CURRENT LOOK
==================================================

Use ONLY on branch:
dominic-photo-engine-clean

FILES TO ADD
------------
1) src/components/visual-references-screen.tsx
2) src/photo-references.css

Then edit src/routes/index.tsx with ONLY two tiny changes.

CHANGE 1 — import
-----------------
Near the top, immediately after:

import { DiarioChat } from "@/components/diario-chat";

add:

import { VisualReferencesScreen } from "@/components/visual-references-screen";


CHANGE 2 — render
-----------------
Search for:

{screen === "references" && <ReferencesScreen />}

replace with:

{screen === "references" && <VisualReferencesScreen />}


IMPORTANT
---------
- Do NOT delete the old local ReferencesScreen yet.
- Do NOT merge into main yet.
- Commit only to dominic-photo-engine-clean.
- Suggested commit message:
  Build visual canon and current look UI

WHAT THIS ADDS
--------------
- Identity vs Current Look
- Alloah / Dominic / Couple / Pose / Style / Place / Wardrobe / Mood boards
- Reference purposes: Face, Body, Hair, Tattoos, Hands, Nails, etc.
- Primary / Supporting / Detail only strength
- Existing reference editing
- Favorite references
- Current Look for Alloah and Dominic
- Current Nails with multiple images
- Historical look stays archived; newest set becomes current
